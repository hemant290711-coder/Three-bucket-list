import { useState, useEffect } from "react";

const STORAGE_KEY = "three-bucket-system";

const defaultData = {
  buckets: {
    money: { label: "Money Maker", desc: "", color: "#F5A623", items: [] },
    soul: { label: "Soul Interest", desc: "", color: "#4A90E2", items: [] },
    other: { label: "Parking Lot", desc: "", color: "#7B7B8B", items: [] },
  },
  logs: [],
  setup: false,
};

const BUCKET_RULES = {
  money: { pct: 80, emoji: "💰", rule: "Your main focus. 80%+ of your time goes here. This is non-negotiable for a full year." },
  soul: { pct: 15, emoji: "🔥", rule: "What fills your soul. Small, scheduled blocks only." },
  other: { pct: 5, emoji: "🗄️", rule: "The parking lot. When a shiny new thing excites you — write it here, don't chase it." },
};

function getWeekLogs(logs) {
  const now = new Date();
  const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
  return logs.filter(l => new Date(l.date) >= weekAgo);
}

function getTotals(logs) {
  const t = { money: 0, soul: 0, other: 0 };
  logs.forEach(l => { t[l.bucket] = (t[l.bucket] || 0) + l.minutes; });
  return t;
}

export default function App() {
  const [data, setData] = useState(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : defaultData;
    } catch { return defaultData; }
  });
  const [tab, setTab] = useState("dashboard");
  const [logForm, setLogForm] = useState({ bucket: "money", minutes: "", note: "" });
  const [newItem, setNewItem] = useState({ bucket: "money", text: "" });
  const [setupStep, setSetupStep] = useState(0);
  const [setupInputs, setSetupInputs] = useState({
    money: { label: "", desc: "" },
    soul: { label: "", desc: "" },
    other: { label: "", desc: "" }
  });
  const [toast, setToast] = useState("");

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch {}
  }, [data]);

  const showToast = (msg) => { setToast(msg); setTimeout(() => setToast(""), 2200); };

  const weekLogs = getWeekLogs(data.logs);
  const totals = getTotals(weekLogs);
  const totalMins = Object.values(totals).reduce((a, b) => a + b, 0);

  function pct(bucket) {
    return totalMins === 0 ? 0 : Math.round((totals[bucket] / totalMins) * 100);
  }

  function addLog() {
    if (!logForm.minutes || isNaN(logForm.minutes) || +logForm.minutes <= 0) return;
    const newLog = { date: new Date().toISOString(), bucket: logForm.bucket, minutes: +logForm.minutes, note: logForm.note };
    setData(d => ({ ...d, logs: [newLog, ...d.logs] }));
    setLogForm(f => ({ ...f, minutes: "", note: "" }));
    showToast("✅ Time logged!");
  }

  function addItem() {
    if (!newItem.text.trim()) return;
    setData(d => ({
      ...d,
      buckets: {
        ...d.buckets,
        [newItem.bucket]: {
          ...d.buckets[newItem.bucket],
          items: [...(d.buckets[newItem.bucket].items || []), newItem.text.trim()],
        },
      },
    }));
    setNewItem(f => ({ ...f, text: "" }));
    showToast(newItem.bucket === "other" ? "🗄️ Parked. Now get back to your money bucket!" : "Added!");
  }

  function removeItem(bucket, idx) {
    setData(d => ({
      ...d,
      buckets: {
        ...d.buckets,
        [bucket]: {
          ...d.buckets[bucket],
          items: d.buckets[bucket].items.filter((_, i) => i !== idx),
        },
      },
    }));
  }

  function finishSetup() {
    setData(d => ({
      ...d,
      setup: true,
      buckets: {
        money: { ...d.buckets.money, label: setupInputs.money.label || "Money Maker", desc: setupInputs.money.desc },
        soul: { ...d.buckets.soul, label: setupInputs.soul.label || "Soul Interest", desc: setupInputs.soul.desc },
        other: { ...d.buckets.other, label: setupInputs.other.label || "Parking Lot", desc: setupInputs.other.desc },
      },
    }));
  }

  if (!data.setup) {
    const steps = ["money", "soul", "other"];
    const current = steps[setupStep];
    const r = BUCKET_RULES[current];
    return (
      <div style={{ minHeight: "100vh", background: "#0E0E12", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Georgia', serif", padding: "24px" }}>
        <div style={{ maxWidth: 480, width: "100%" }}>
          <div style={{ textAlign: "center", marginBottom: 32 }}>
            <div style={{ fontSize: 13, letterSpacing: 4, color: "#555", textTransform: "uppercase", marginBottom: 8 }}>The 3-Bucket Method</div>
            <div style={{ fontSize: 36, fontWeight: 700, color: "#fff" }}>Setup your system</div>
            <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 16 }}>
              {steps.map((s, i) => (
                <div key={s} style={{ width: 32, height: 4, borderRadius: 2, background: i <= setupStep ? "#F5A623" : "#222" }} />
              ))}
            </div>
          </div>

          <div style={{ background: "#16161C", border: "1px solid #2a2a35", borderRadius: 16, padding: 28 }}>
            <div style={{ fontSize: 32, marginBottom: 4 }}>{r.emoji}</div>
            <div style={{ fontSize: 11, letterSpacing: 3, color: "#666", textTransform: "uppercase", marginBottom: 4 }}>Bucket {setupStep + 1}</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: "#fff", marginBottom: 8 }}>
              {current === "money" ? "What makes you money?" : current === "soul" ? "What feeds your soul?" : "What's your parking lot?"}
            </div>
            <div style={{ fontSize: 13, color: "#888", marginBottom: 20, lineHeight: 1.6 }}>{r.rule}</div>

            <div style={{ marginBottom: 12 }}>
              <input
                placeholder={current === "money" ? "e.g. Freelance design, YouTube, SaaS..." : current === "soul" ? "e.g. Oil painting, music production..." : "Anything new & exciting goes here"}
                value={setupInputs[current].label}
                onChange={e => setSetupInputs(s => ({ ...s, [current]: { ...s[current], label: e.target.value } }))}
                style={{ width: "100%", background: "#0E0E12", border: "1px solid #333", borderRadius: 8, padding: "12px 14px", color: "#fff", fontSize: 15, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }}
              />
            </div>
            <div style={{ marginBottom: 20 }}>
              <textarea
                placeholder="Describe your goal for this bucket (optional)"
                value={setupInputs[current].desc}
                onChange={e => setSetupInputs(s => ({ ...s, [current]: { ...s[current], desc: e.target.value } }))}
                rows={2}
                style={{ width: "100%", background: "#0E0E12", border: "1px solid #333", borderRadius: 8, padding: "12px 14px", color: "#fff", fontSize: 13, fontFamily: "inherit", resize: "none", boxSizing: "border-box", outline: "none" }}
              />
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              {setupStep > 0 && (
                <button onClick={() => setSetupStep(s => s - 1)} style={{ flex: 1, padding: "12px", background: "#222", color: "#aaa", border: "none", borderRadius: 8, fontSize: 14, cursor: "pointer" }}>← Back</button>
              )}
              <button
                onClick={() => setupStep < 2 ? setSetupStep(s => s + 1) : finishSetup()}
                style={{ flex: 2, padding: "12px", background: "#F5A623", color: "#000", border: "none", borderRadius: 8, fontSize: 15, fontWeight: 700, cursor: "pointer" }}
              >
                {setupStep < 2 ? "Next →" : "Start the System 🚀"}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const moneyPct = pct("money");
  const isOnTrack = totalMins > 0 && moneyPct >= 80;

  return (
    <div style={{ minHeight: "100vh", background: "#0E0E12", fontFamily: "'Georgia', serif", color: "#fff" }}>
      {toast && (
        <div style={{ position: "fixed", top: 20, left: "50%", transform: "translateX(-50%)", background: "#222", color: "#fff", padding: "10px 22px", borderRadius: 30, fontSize: 13, zIndex: 999, border: "1px solid #444", boxShadow: "0 4px 20px #0008" }}>
          {toast}
        </div>
      )}

      <div style={{ padding: "20px 20px 0", maxWidth: 600, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 11, letterSpacing: 3, color: "#555", textTransform: "uppercase" }}>3-Bucket System</div>
            <div style={{ fontSize: 22, fontWeight: 700 }}>Your Focus OS</div>
          </div>
          <button onClick={() => setData(d => ({ ...d, setup: false }))} style={{ background: "none", border: "1px solid #333", color: "#666", padding: "6px 12px", borderRadius: 6, fontSize: 11, cursor: "pointer" }}>⚙ Edit</button>
        </div>

        <div style={{ display: "flex", gap: 4, background: "#16161C", borderRadius: 10, padding: 4, marginBottom: 20 }}>
          {[["dashboard", "📊 Dashboard"], ["log", "⏱ Log Time"], ["buckets", "🗂 Buckets"]].map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} style={{ flex: 1, padding: "8px 4px", background: tab === k ? "#222" : "transparent", border: "none", color: tab === k ? "#fff" : "#666", borderRadius: 7, fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>{l}</button>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 600, margin: "0 auto", padding: "0 20px 40px" }}>

        {tab === "dashboard" && (
          <div>
            <div style={{ background: isOnTrack ? "#0d2b0d" : totalMins === 0 ? "#1a1a22" : "#2b1a0d", border: `1px solid ${isOnTrack ? "#2d5a2d" : totalMins === 0 ? "#2a2a35" : "#5a3a0d"}`, borderRadius: 12, padding: "14px 18px", marginBottom: 16, display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 22 }}>{isOnTrack ? "🟢" : totalMins === 0 ? "⚪" : "🔴"}</span>
              <div>
                <div style={{ fontSize: 13, fontWeight: 700, color: isOnTrack ? "#6fcf6f" : totalMins === 0 ? "#888" : "#e09040" }}>
                  {isOnTrack ? "On Track — Keep going!" : totalMins === 0 ? "No logs yet this week. Start today." : `Off track — ${moneyPct}% on money bucket. Target is 80%+`}
                </div>
                <div style={{ fontSize: 11, color: "#666", marginTop: 2 }}>Based on last 7 days · {Math.round(totalMins / 60)}h {totalMins % 60}m logged</div>
              </div>
            </div>

            {["money", "soul", "other"].map(b => {
              const r = BUCKET_RULES[b];
              const p = pct(b);
              const bkt = data.buckets[b];
              return (
                <div key={b} style={{ background: "#16161C", border: "1px solid #2a2a35", borderRadius: 12, padding: "16px 18px", marginBottom: 10 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 18 }}>{r.emoji}</span>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 700 }}>{bkt.label}</div>
                        {bkt.desc && <div style={{ fontSize: 11, color: "#666" }}>{bkt.desc}</div>}
                      </div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 22, fontWeight: 700, color: bkt.color }}>{p}%</div>
                      <div style={{ fontSize: 10, color: "#555" }}>target: {b === "money" ? "≥80%" : b === "soul" ? "≤15%" : "≤5%"}</div>
                    </div>
                  </div>
                  <div style={{ background: "#0E0E12", borderRadius: 6, height: 8, overflow: "hidden" }}>
                    <div style={{ width: `${Math.min(p, 100)}%`, height: "100%", background: bkt.color, borderRadius: 6, transition: "width 0.6s ease" }} />
                  </div>
                  <div style={{ fontSize: 11, color: "#555", marginTop: 6 }}>{Math.round(totals[b] / 60)}h {totals[b] % 60}m this week</div>
                </div>
              );
            })}

            <div style={{ marginTop: 20 }}>
              <div style={{ fontSize: 11, letterSpacing: 3, color: "#555", textTransform: "uppercase", marginBottom: 10 }}>Recent Activity</div>
              {data.logs.slice(0, 5).map((l, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid #1a1a22", alignItems: "center" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 14 }}>{BUCKET_RULES[l.bucket].emoji}</span>
                    <div>
                      <div style={{ fontSize: 13, color: data.buckets[l.bucket].color, fontWeight: 600 }}>{data.buckets[l.bucket].label}</div>
                      {l.note && <div style={{ fontSize: 11, color: "#666" }}>{l.note}</div>}
                    </div>
                  </div>
                  <div style={{ fontSize: 12, color: "#888" }}>{l.minutes}m · {new Date(l.date).toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" })}</div>
                </div>
              ))}
              {data.logs.length === 0 && <div style={{ fontSize: 13, color: "#555", textAlign: "center", padding: "20px 0" }}>No logs yet. Go to "Log Time" to start.</div>}
            </div>
          </div>
        )}

        {tab === "log" && (
          <div>
            <div style={{ fontSize: 11, letterSpacing: 3, color: "#555", textTransform: "uppercase", marginBottom: 14 }}>Log Time Spent</div>
            <div style={{ background: "#16161C", border: "1px solid #2a2a35", borderRadius: 14, padding: 20, marginBottom: 16 }}>
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 11, color: "#666", marginBottom: 6 }}>BUCKET</div>
                <div style={{ display: "flex", gap: 6 }}>
                  {["money", "soul", "other"].map(b => (
                    <button key={b} onClick={() => setLogForm(f => ({ ...f, bucket: b }))}
                      style={{ flex: 1, padding: "10px 4px", background: logForm.bucket === b ? data.buckets[b].color : "#111", color: logForm.bucket === b ? "#000" : "#888", border: `1px solid ${logForm.bucket === b ? data.buckets[b].color : "#333"}`, borderRadius: 8, fontSize: 11, cursor: "pointer", fontFamily: "inherit", fontWeight: logForm.bucket === b ? 700 : 400 }}>
                      {BUCKET_RULES[b].emoji} {data.buckets[b].label.split(" ")[0]}
                    </button>
                  ))}
                </div>
              </div>
              <div style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 11, color: "#666", marginBottom: 6 }}>MINUTES SPENT</div>
                <input
                  type="number" placeholder="e.g. 90"
                  value={logForm.minutes}
                  onChange={e => setLogForm(f => ({ ...f, minutes: e.target.value }))}
                  style={{ width: "100%", background: "#0E0E12", border: "1px solid #333", borderRadius: 8, padding: "12px 14px", color: "#fff", fontSize: 16, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }}
                />
              </div>
              <div style={{ marginBottom: 18 }}>
                <div style={{ fontSize: 11, color: "#666", marginBottom: 6 }}>WHAT DID YOU DO? (optional)</div>
                <input
                  placeholder="Quick note..."
                  value={logForm.note}
                  onChange={e => setLogForm(f => ({ ...f, note: e.target.value }))}
                  style={{ width: "100%", background: "#0E0E12", border: "1px solid #333", borderRadius: 8, padding: "12px 14px", color: "#fff", fontSize: 14, fontFamily: "inherit", boxSizing: "border-box", outline: "none" }}
                />
              </div>
              <button onClick={addLog} style={{ width: "100%", padding: "14px", background: "#F5A623", color: "#000", border: "none", borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>
                Log It
              </button>
            </div>
            <div style={{ background: "#0d1a0d", border: "1px solid #1e3a1e", borderRadius: 10, padding: "12px 16px" }}>
              <div style={{ fontSize: 12, color: "#4a9a4a", lineHeight: 1.7 }}>
                💡 <strong>The Rule:</strong> If something new and exciting appears — <strong>don't start it</strong>. Park it in the Parking Lot and come back to your money work.
              </div>
            </div>
          </div>
        )}

        {tab === "buckets" && (
          <div>
            <div style={{ background: "#16161C", border: "1px solid #2a2a35", borderRadius: 14, padding: 18, marginBottom: 20 }}>
              <div style={{ fontSize: 11, color: "#666", marginBottom: 8, letterSpacing: 2, textTransform: "uppercase" }}>Add to a bucket</div>
              <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
                {["money", "soul", "other"].map(b => (
                  <button key={b} onClick={() => setNewItem(f => ({ ...f, bucket: b }))}
                    style={{ flex: 1, padding: "8px 4px", background: newItem.bucket === b ? data.buckets[b].color : "#111", color: newItem.bucket === b ? "#000" : "#888", border: `1px solid ${newItem.bucket === b ? data.buckets[b].color : "#333"}`, borderRadius: 7, fontSize: 11, cursor: "pointer", fontFamily: "inherit", fontWeight: newItem.bucket === b ? 700 : 400 }}>
                    {BUCKET_RULES[b].emoji} {data.buckets[b].label.split(" ")[0]}
                  </button>
                ))}
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  placeholder={newItem.bucket === "other" ? "New shiny thing to park..." : "Add a task or idea..."}
                  value={newItem.text}
                  onChange={e => setNewItem(f => ({ ...f, text: e.target.value }))}
                  onKeyDown={e => e.key === "Enter" && addItem()}
                  style={{ flex: 1, background: "#0E0E12", border: "1px solid #333", borderRadius: 8, padding: "10px 14px", color: "#fff", fontSize: 14, fontFamily: "inherit", outline: "none" }}
                />
                <button onClick={addItem} style={{ padding: "10px 16px", background: data.buckets[newItem.bucket].color, color: "#000", border: "none", borderRadius: 8, fontWeight: 700, cursor: "pointer", fontSize: 14 }}>+</button>
              </div>
            </div>

            {["money", "soul", "other"].map(b => {
              const r = BUCKET_RULES[b];
              const bkt = data.buckets[b];
              return (
                <div key={b} style={{ marginBottom: 18 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                    <span>{r.emoji}</span>
                    <div style={{ fontSize: 14, fontWeight: 700, color: bkt.color }}>{bkt.label}</div>
                    <div style={{ fontSize: 10, color: "#555" }}>· {r.pct === 80 ? "≥80%" : r.pct === 15 ? "≤15%" : "≤5%"} of your time</div>
                  </div>
                  <div style={{ fontSize: 11, color: "#666", marginBottom: 8 }}>{r.rule}</div>
                  {(bkt.items || []).length === 0 && (
                    <div style={{ fontSize: 12, color: "#444", fontStyle: "italic", padding: "8px 0" }}>Empty — add something above</div>
                  )}
                  {(bkt.items || []).map((item, i) => (
                    <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 12px", background: "#16161C", borderRadius: 8, marginBottom: 5, border: "1px solid #1e1e28" }}>
                      <span style={{ fontSize: 13 }}>{item}</span>
                      <button onClick={() => removeItem(b, i)} style={{ background: "none", border: "none", color: "#444", cursor: "pointer", fontSize: 16, lineHeight: 1 }}>×</button>
                    </div>
                  ))}
                </div>
              );
            })}

            <button onClick={() => { if (window.confirm("Reset everything?")) { setData(defaultData); } }} style={{ marginTop: 10, background: "none", border: "1px solid #3a1a1a", color: "#884444", borderRadius: 8, padding: "8px 16px", fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>
              Reset system
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
