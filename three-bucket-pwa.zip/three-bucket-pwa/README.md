# 3-Bucket Focus System — PWA

A mobile-installable focus app based on the 3-bucket method.

---

## 🚀 Deploy to Vercel in 5 minutes

### Step 1 — Install Node.js
Download from https://nodejs.org (LTS version)

### Step 2 — Upload to GitHub
1. Go to https://github.com and create a free account
2. Click "New repository" → name it `three-bucket-app` → Create
3. Upload all these files (drag & drop the whole folder)

### Step 3 — Deploy on Vercel
1. Go to https://vercel.com → Sign up with GitHub
2. Click "Add New Project"
3. Import your `three-bucket-app` repo
4. Framework preset: **Vite**
5. Click **Deploy** — done in ~60 seconds

Your app will be live at: `https://three-bucket-app.vercel.app`

---

## 📱 Install as App on Phone

### iPhone (Safari):
1. Open your Vercel URL in Safari
2. Tap the **Share** button (box with arrow)
3. Tap **"Add to Home Screen"**
4. Tap **Add** — it appears like a real app!

### Android (Chrome):
1. Open your Vercel URL in Chrome
2. Tap the **3-dot menu**
3. Tap **"Add to Home Screen"** or **"Install App"**
4. Done!

---

## 🛠 Run Locally (optional)

```bash
npm install
npm run dev
```

Then open http://localhost:5173

---

## Project Structure

```
three-bucket-pwa/
├── index.html          # Entry HTML
├── vite.config.js      # Vite + PWA config
├── package.json        # Dependencies
├── vercel.json         # Vercel routing
├── public/
│   ├── favicon.ico
│   └── icons/
│       ├── icon-192.png
│       └── icon-512.png
└── src/
    ├── main.jsx        # React entry
    └── App.jsx         # Full app
```
